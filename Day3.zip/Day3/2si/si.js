function SICalculator(a,b,c)
{
    
    var p =document.getElementById('x1').value;
    var r =document.getElementById('x2').value;
    var t =document.getElementById('x3').value;

    console.log(p,r,t);

    var r = (p*r*t)/100;

    console.log(document.getElementById("result"));
    document.getElementById("result").innerHTML=r;




}