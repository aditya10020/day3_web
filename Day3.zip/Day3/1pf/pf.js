// alert("Please stay alert!!")
// confirm("Are sure to Exit?")

function PFCalculator(a,b,c){
    //console.log("Hello",a,b,c);

    //  console.log(document);//html document
    //  console.log(typeof document);//object

    var amount = document.getElementById('x1').value
    var interest = document.getElementById('x2').value
    var duration = document.getElementById('x3').value
 //to check if any box is left unfilled
    if(amount==""||interest==""||duration=="")
    {
        alert("Please Pass all Value")
    }
    else
    {
        amt=parseInt(amount);
        roi=parseFloat(interest);
        duration=parseInt(duration);

        var openingBalance= 0;
        var x="";
        for(var i=1;i<=duration;i++)
        {   
            var interestEarned= Math.round((openingBalance+amt)*roi/100);
            var closingBalance= openingBalance+amt+interestEarned;
            console.log(i,openingBalance,amt,interestEarned,closingBalance);

            x=x+`
                <tr>
                    <td>${i}</td>
                    <td>${openingBalance}</td>
                    <td>${amt}</td>
                    <td>${interestEarned}</td>
                    <td>${closingBalance}</td>
                </tr>
            `
            openingBalance=closingBalance;
        }
        //here we have only declared x and result
        // console.log(x);
         console.log(document.getElementById("result"));
        // //DOM Property innerHTML
       document.getElementById("result").innerHTML= x;

    }

    
}