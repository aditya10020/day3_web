// alert("Enter complete information to validate")
var Verifier=function()
{
    var info= document.getElementById('x1').value
    console.log(info)

    //pincode
    // var expression= /^[1-9][0-9][0-9][0-9][0-9][0-9]$/
    //  var expression= /^[1-9][0-9]{5}$/

    //mobile number
    //  var expression= /^[6-9][0-9]{9}$/


    //  var expression= /^[A-Z]{5}[1-9]{4}[A-Z]$/


    //  var expression= /^[a-zA-Z]([a-zA-Z ]{1,})?[a-zA-Z]$/
     




    var answer = expression.test(info)
    console.log(answer)


}
    
