in header section
    figure col-xl-3
        img from images/home/logo.png
    nav col-xl-9
        apply:
        https://getbootstrap.com/docs/5.2/components/navs-tabs/#horizontal-alignment


surajjadhaveshop
QxU^C1I1exF)DzigJ63v


    navbar --
    https://getbootstrap.com/docs/5.2/components/navbar/#how-it-works


slider
    https://getbootstrap.com/docs/5.2/components/carousel/

product
    .col-xl-3
        section-accordion
        https://getbootstrap.com/docs/5.2/components/accordion/#how-it-works


for font awesome:
https://cdnjs.com/libraries/font-awesome